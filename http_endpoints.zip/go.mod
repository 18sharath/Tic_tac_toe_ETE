module tic_tac_toe

go 1.26.1

require github.com/google/uuid v1.6.0
